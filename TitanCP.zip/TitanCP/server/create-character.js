const mysql = require('mysql2');

function createCharacter(accountId, charName, charClass = 0) {
  return new Promise((resolve, reject) => {
    const connection = mysql.createConnection({
      host: 'localhost',
      port: 3306,
      user: 'root',
      password: 'usbw',
      database: 'ragnarok_db'
    });

    connection.connect((err) => {
      if (err) {
        reject(err);
        return;
      }

      // Сначала проверим существование аккаунта
      connection.query(
        'SELECT account_id FROM login WHERE account_id = ?',
        [accountId],
        (err, results) => {
          if (err) {
            connection.end();
            reject(err);
            return;
          }

          if (results.length === 0) {
            connection.end();
            reject(new Error(`Аккаунт с ID ${accountId} не существует`));
            return;
          }

          // Проверим существование имени персонажа
          connection.query(
            'SELECT char_id FROM `char` WHERE name = ?',
            [charName],
            (err, results) => {
              if (err) {
                connection.end();
                reject(err);
                return;
              }

              if (results.length > 0) {
                connection.end();
                reject(new Error(`Персонаж с именем "${charName}" уже существует`));
                return;
              }

              // Определяем следующий доступный char_num
              connection.query(
                'SELECT COALESCE(MAX(char_num), -1) + 1 as next_char_num FROM `char` WHERE account_id = ?',
                [accountId],
                (err, results) => {
                  if (err) {
                    connection.end();
                    reject(err);
                    return;
                  }

                  const nextCharNum = results[0].next_char_num;
                  
                  // Стартовые параметры в зависимости от класса
                  const startStats = getStartStats(charClass);
                  
                  // Создаем персонажа
                  connection.query(
                    `INSERT INTO \`char\` (
                      account_id, char_num, name, class, base_level, job_level, 
                      zeny, last_map, str, agi, vit, int, dex, luk
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                    [
                      accountId, nextCharNum, charName, charClass,
                      1, 1, 1000, 'prontera',
                      startStats.str, startStats.agi, startStats.vit,
                      startStats.int, startStats.dex, startStats.luk
                    ],
                    (err, result) => {
                      connection.end();
                      
                      if (err) {
                        reject(err);
                        return;
                      }

                      resolve({
                        success: true,
                        charId: result.insertId,
                        charName: charName,
                        charNum: nextCharNum,
                        class: charClass,
                        message: `Персонаж "${charName}" успешно создан`
                      });
                    }
                  );
                }
              );
            }
          );
        }
      );
    });
  });
}

function getStartStats(charClass) {
  const stats = {
    0: { str: 5, agi: 5, vit: 5, int: 5, dex: 5, luk: 5 }, // Новичок
    1: { str: 9, agi: 5, vit: 7, int: 1, dex: 5, luk: 3 }, // Мечник
    2: { str: 1, agi: 5, vit: 3, int: 9, dex: 6, luk: 6 }, // Волшебник
    3: { str: 5, agi: 9, vit: 3, int: 5, dex: 9, luk: 4 }, // Лучник
    4: { str: 6, agi: 6, vit: 6, int: 6, dex: 6, luk: 6 }, // Торговец
    5: { str: 5, agi: 9, vit: 3, int: 5, dex: 9, luk: 4 }, // Вор
    6: { str: 6, agi: 6, vit: 6, int: 6, dex: 6, luk: 6 }, // Аколыт
    7: { str: 5, agi: 5, vit: 5, int: 5, dex: 5, luk: 5 }  // Супер-новичок
  };
  
  return stats[charClass] || stats[0];
}

// Пример использования
if (require.main === module) {
  createCharacter(2000001, 'MyNewCharacter', 0)
    .then(result => {
      console.log('✅', result.message);
      console.log('📊 Детали:', {
        ID: result.charId,
        Имя: result.charName,
        Номер: result.charNum,
        Класс: result.class
      });
    })
    .catch(error => {
      console.error('❌ Ошибка:', error.message);
    });
}

module.exports = { createCharacter };