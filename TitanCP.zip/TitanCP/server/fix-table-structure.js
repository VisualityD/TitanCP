const mysql = require('mysql2');

console.log('🔧 Fixing table structure for bcrypt passwords...');

const connection = mysql.createConnection({
  host: 'localhost',
  port: 3306,
  user: 'root',
  password: 'usbw',
  database: 'ragnarok_db'
});

connection.connect((err) => {
  if (err) {
    console.error('❌ Connection failed:', err.message);
    return;
  }

  console.log('✅ Connected to database');

  // Изменяем тип поля user_pass чтобы вмещать bcrypt хеши (60+ символов)
  const alterQuery = `
    ALTER TABLE login 
    MODIFY user_pass VARCHAR(255) NOT NULL DEFAULT ''
  `;

  connection.query(alterQuery, (err, result) => {
    if (err) {
      console.error('❌ Alter table failed:', err.message);
    } else {
      console.log('✅ Table structure updated successfully');
      console.log('📝 user_pass field now supports bcrypt hashes (255 characters)');
    }

    // Также увеличим поле email на всякий случай
    connection.query(`
      ALTER TABLE login 
      MODIFY email VARCHAR(255) NOT NULL DEFAULT ''
    `, (err, result) => {
      if (err) {
        console.log('⚠️ Could not alter email field:', err.message);
      } else {
        console.log('✅ Email field updated to 255 characters');
      }

      connection.end();
      console.log('🎉 Table structure fixes completed!');
    });
  });
});