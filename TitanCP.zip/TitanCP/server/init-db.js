const mysql = require('mysql2');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');

// Загружаем .env файл вручную
const envPath = path.join(__dirname, '..', '.env');
console.log('🔍 Looking for .env file at:', envPath);

if (fs.existsSync(envPath)) {
  console.log('✅ .env file found');
  const envContent = fs.readFileSync(envPath, 'utf8');
  const envLines = envContent.split('\n');
  
  envLines.forEach(line => {
    if (line.trim() && !line.startsWith('#')) {
      const [key, value] = line.split('=');
      if (key && value) {
        process.env[key.trim()] = value.trim();
      }
    }
  });
  console.log('📋 Loaded environment variables');
} else {
  console.log('❌ .env file not found, using defaults');
}

function initializeDatabase() {
  return new Promise((resolve, reject) => {
    console.log('🔧 Initializing database for USBWebServer MySQL...');
    
    const dbConfig = {
      host: process.env.DB_HOST || 'localhost',
      port: parseInt(process.env.DB_PORT) || 3306,
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASSWORD || 'usbw',
      database: process.env.DB_NAME || 'ragnarok_db'
    };

    console.log('📋 Connection details:', {
      ...dbConfig,
      password: dbConfig.password ? '***' + dbConfig.password.slice(-2) : 'empty'
    });

    // Создаем соединение (не promise-based)
    const connection = mysql.createConnection(dbConfig);

    connection.connect((err) => {
      if (err) {
        console.error('❌ Connection failed:', err.message);
        reject(err);
        return;
      }

      console.log('✅ Connected to MySQL server');

      // Создаем базу данных если не существует
      connection.query(`CREATE DATABASE IF NOT EXISTS \`${dbConfig.database}\``, (err) => {
        if (err) {
          console.error('❌ Create database failed:', err.message);
          connection.end();
          reject(err);
          return;
        }

        console.log('✅ Database created/verified');

        // Используем базу данных
        connection.query(`USE \`${dbConfig.database}\``, (err) => {
          if (err) {
            console.error('❌ Use database failed:', err.message);
            connection.end();
            reject(err);
            return;
          }

          console.log('✅ Using database:', dbConfig.database);
          
          // Создаем таблицы
          createTables(connection)
            .then(() => {
              console.log('🎉 Database initialization completed successfully!');
              connection.end();
              resolve();
            })
            .catch((err) => {
              console.error('❌ Create tables failed:', err.message);
              connection.end();
              reject(err);
            });
        });
      });
    });

    connection.on('error', (err) => {
      console.error('❌ Connection error:', err.message);
      reject(err);
    });
  });
}

function createTables(connection) {
  return new Promise((resolve, reject) => {
    console.log('📝 Creating tables...');

    // Сначала удаляем существующие таблицы если они есть (для чистоты)
    const tablesToDrop = ['news', 'char', 'site_settings', 'login'];
    
    let tablesDropped = 0;
    const totalTables = tablesToDrop.length;

    if (totalTables === 0) {
      createTablesStructure();
      return;
    }

    tablesToDrop.forEach(table => {
      connection.query(`DROP TABLE IF EXISTS \`${table}\``, (err) => {
        if (err) {
          console.log(`⚠️ Could not drop table ${table}:`, err.message);
        } else {
          console.log(`✅ Dropped table ${table}`);
        }
        
        tablesDropped++;
        if (tablesDropped === totalTables) {
          createTablesStructure();
        }
      });
    });

    function createTablesStructure() {
      // Создаем таблицу login
      connection.query(`
        CREATE TABLE \`login\` (
          \`account_id\` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
          \`userid\` VARCHAR(23) NOT NULL DEFAULT '',
          \`user_pass\` VARCHAR(255) NOT NULL DEFAULT '',
          \`sex\` ENUM('M','F','S') NOT NULL DEFAULT 'M',
          \`email\` VARCHAR(39) NOT NULL DEFAULT '',
          \`group_id\` TINYINT(3) NOT NULL DEFAULT '0',
          \`state\` INT(11) UNSIGNED NOT NULL DEFAULT '0',
          \`logincount\` MEDIUMINT(9) UNSIGNED NOT NULL DEFAULT '0',
          \`lastlogin\` DATETIME NULL DEFAULT NULL,
          \`last_ip\` VARCHAR(100) NOT NULL DEFAULT '',
          \`character_slots\` TINYINT(3) UNSIGNED NOT NULL DEFAULT '9',
          PRIMARY KEY (\`account_id\`),
          UNIQUE KEY \`userid\` (\`userid\`)
        ) ENGINE=InnoDB AUTO_INCREMENT=2000000 DEFAULT CHARSET=utf8mb4
      `, (err) => {
        if (err) {
          console.error('❌ Create login table failed:', err.message);
          reject(err);
          return;
        }

        console.log('✅ Created login table');

        // Добавляем тестового пользователя (администратора)
        const adminHashedPassword = bcrypt.hashSync('test', 10);
        
        connection.query(`
          INSERT INTO \`login\` 
            (account_id, userid, user_pass, sex, email, group_id, character_slots) 
          VALUES 
            (1, 'test', ?, 'S', 'test@test.com', 99, 9)
        `, [adminHashedPassword], (err) => {
          if (err) {
            console.error('❌ Add test admin user failed:', err.message);
            reject(err);
            return;
          }

          console.log('✅ Added test admin user (login: test, password: test, group_id: 99)');

          // Добавляем обычного тестового пользователя
          const userHashedPassword = bcrypt.hashSync('user', 10);
          connection.query(`
            INSERT INTO \`login\` 
              (account_id, userid, user_pass, sex, email, group_id, character_slots) 
            VALUES 
              (2, 'user', ?, 'M', 'user@test.com', 0, 9)
          `, [userHashedPassword], (err) => {
            if (err) {
              console.error('❌ Add regular user failed:', err.message);
              reject(err);
              return;
            }

            console.log('✅ Added regular user (login: user, password: user, group_id: 0)');

            // Таблица персонажей - УПРОЩЕННАЯ ВЕРСИЯ
            connection.query(`
              CREATE TABLE \`char\` (
                \`char_id\` INT(11) UNSIGNED NOT NULL AUTO_INCREMENT,
                \`account_id\` INT(11) UNSIGNED NOT NULL DEFAULT '0',
                \`name\` VARCHAR(30) NOT NULL DEFAULT '',
                \`class\` SMALLINT(6) UNSIGNED NOT NULL DEFAULT '0',
                \`base_level\` SMALLINT(6) UNSIGNED NOT NULL DEFAULT '1',
                \`job_level\` SMALLINT(6) UNSIGNED NOT NULL DEFAULT '1',
                \`zeny\` INT(11) UNSIGNED NOT NULL DEFAULT '0',
                \`last_map\` VARCHAR(50) NOT NULL DEFAULT 'prontera',
                \`online\` TINYINT(2) NOT NULL DEFAULT '0',
                PRIMARY KEY (\`char_id\`),
                UNIQUE KEY \`name\` (\`name\`),
                KEY \`account_id\` (\`account_id\`)
              ) ENGINE=InnoDB AUTO_INCREMENT=150000 DEFAULT CHARSET=utf8mb4
            `, (err) => {
              if (err) {
                console.error('❌ Create char table failed:', err.message);
                reject(err);
                return;
              }

              console.log('✅ Created char table');

              // Добавим тестового персонажа для администратора - ТОЛЬКО БАЗОВЫЕ ПОЛЯ
              connection.query(`
                INSERT INTO \`char\` 
                  (char_id, account_id, name, class, base_level, job_level, zeny, last_map) 
                VALUES 
                  (1, 1, 'AdminChar', 0, 99, 50, 100000, 'prontera')
              `, (err) => {
                if (err) {
                  console.error('❌ Add admin character failed:', err.message);
                  console.error('❌ Error details:', err);
                  reject(err);
                  return;
                }

                console.log('✅ Added admin character');

                // Добавим тестового персонажа для обычного пользователя
                connection.query(`
                  INSERT INTO \`char\` 
                    (char_id, account_id, name, class, base_level, job_level, zeny, last_map) 
                  VALUES 
                    (2, 2, 'PlayerChar', 1, 50, 25, 50000, 'prontera')
                `, (err) => {
                  if (err) {
                    console.error('❌ Add player character failed:', err.message);
                    reject(err);
                    return;
                  }

                  console.log('✅ Added player character');

                  // Таблица настроек сайта
                  connection.query(`
                    CREATE TABLE \`site_settings\` (
                      \`id\` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                      \`setting_key\` VARCHAR(255) NOT NULL,
                      \`setting_value\` TEXT NOT NULL,
                      \`updated_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                      PRIMARY KEY (\`id\`),
                      UNIQUE KEY \`setting_key\` (\`setting_key\`)
                    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
                  `, (err) => {
                    if (err) {
                      console.error('❌ Create site_settings table failed:', err.message);
                      reject(err);
                      return;
                    }

                    console.log('✅ Created site_settings table');

                    // Добавляем настройки по умолчанию
                    const defaultSettings = [
                      ['site_title', 'Ragnarok Online | Официальный сервер'],
                      ['welcome_title', 'Добро пожаловать в Ragnarok Online'],
                      ['welcome_subtitle', 'Присоединяйтесь к эпическому приключению в загадочном мире Midgard'],
                      ['server_ip', 'localhost'],
                      ['login_port', '6900'],
                      ['char_port', '6121'],
                      ['map_port', '5121'],
                      ['server_status', 'online'],
                      ['max_players', '1000']
                    ];

                    let settingsInserted = 0;
                    const totalSettings = defaultSettings.length;

                    function insertNextSetting() {
                      if (settingsInserted >= totalSettings) {
                        console.log('✅ All site settings inserted');
                        console.log('\n🎉 Database initialization completed successfully!');
                        console.log('\n📊 Database structure created:');
                        console.log('   ✅ login table - accounts system');
                        console.log('   ✅ char table - characters system');
                        console.log('   ✅ site_settings table - website configuration');
                        console.log('\n👤 Test accounts:');
                        console.log('   🔹 Admin: login="test", password="test" (group_id: 99)');
                        console.log('   🔹 User: login="user", password="user" (group_id: 0)');
                        console.log('\n🎮 Test characters:');
                        console.log('   🔹 AdminChar (account_id: 1)');
                        console.log('   🔹 PlayerChar (account_id: 2)');
                        console.log('\n⚙️ Server is ready to use!');
                        resolve();
                        return;
                      }

                      const [key, value] = defaultSettings[settingsInserted];
                      connection.query(`
                        INSERT INTO \`site_settings\` (setting_key, setting_value)
                        VALUES (?, ?)
                      `, [key, value], (err) => {
                        if (err) {
                          console.error(`❌ Failed to insert setting ${key}:`, err.message);
                        } else {
                          console.log(`✅ Added setting: ${key} = ${value}`);
                        }
                        
                        settingsInserted++;
                        insertNextSetting();
                      });
                    }

                    insertNextSetting();
                  });
                });
              });
            });
          });
        });
      });
    }
  });
}

// Запускаем инициализацию если скрипт вызван напрямую
if (require.main === module) {
  initializeDatabase()
    .then(() => {
      console.log('\n🚀 Database initialization completed successfully!');
      process.exit(0);
    })
    .catch((error) => {
      console.error('\n💥 Fatal error:', error.message);
      console.error('💥 Full error:', error);
      process.exit(1);
    });
}

module.exports = { initializeDatabase };