const mysql = require('mysql2');

console.log('🧪 Testing MySQL connection to USBWebServer...');

const connection = mysql.createConnection({
  host: 'localhost',
  port: 3306,
  user: 'root',
  password: 'usbw',
});

connection.connect((err) => {
  if (err) {
    console.error('❌ Connection failed:', err.message);
    console.log('\n💡 Please check:');
    console.log('   1. Is USBWebServer running?');
    console.log('   2. Is MySQL service started in USBWebServer control panel?');
    console.log('   3. Is port 3306 available?');
    console.log('   4. Try opening http://localhost/ in browser to access USBWebServer');
  } else {
    console.log('✅ Successfully connected to MySQL!');
    
    // Показать базы данных
    connection.query('SHOW DATABASES', (err, results) => {
      if (err) {
        console.error('Error showing databases:', err);
      } else {
        console.log('\n📊 Available databases:');
        results.forEach(db => {
          console.log('   -', db.Database);
        });
      }
      connection.end();
    });
  }
});